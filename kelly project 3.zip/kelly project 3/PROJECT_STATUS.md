# Kelly Project 3 — Project Status

**Last updated:** 2026-08-30 (final completion pass — see §8)
**Purpose of this file:** so anyone — including a future AI session with zero prior context — can understand the current state of this design without re-deriving it from scratch. Everything here was verified directly against the schematic files and/or `kicad-cli` ERC/netlist output as of the date above. Anything not independently verified is explicitly flagged as such.

---

## 1. What this project is

**Kelly Project 3** is an ESP32-P4-based **Smart Video Doorbell Camera Unit** — the outdoor doorbell/camera device itself.

> **Important scope note:** the "chime" that rings inside the house is a **separate, physical off-board unit** — it is not part of this PCB. This project only contains the circuitry that *talks to* an off-board chime module (driver IC + amp + a 3-pin connector, J6, described below). Do not confuse the on-board "chime subsystem" (U9/U10/J6) with the chime device itself.

The unit captures video (camera + mic), plays audio out a local speaker (visitor-facing "hello" style prompts), detects motion (PIR) and button presses, illuminates at night (IR LEDs), stores footage locally (microSD), and talks to a companion chime unit and to WiFi/BT infrastructure.

---

## 2. Architecture summary

| Subsystem | Parts | Notes |
|---|---|---|
| **Main MCU** | ESP32-P4NRW32 (U5) | Dual-core RISC-V, native MIPI-CSI camera input, native USB, SDMMC. No native WiFi/BT — see co-processor below. |
| **Wireless co-processor** | ESP32-C6FH4 (U8) | Provides WiFi/BT; connects to the P4 over **SDIO** (SDIO_CMD/CLK/D0–D3), not UART. |
| **Camera** | LI-OV5640-MIPI-AF (U15) | 2-lane MIPI-CSI, wired **directly** to the P4 (no intermediate bridge chip). Custom footprint built from the module's official spec sheet — no manufacturer/SnapEDA footprint existed for it. |
| **Audio** | ES8388 codec (U11) + PAM8302AAD power amp (U12) + electret mic (J7, off-board) | ES8388 handles ADC/DAC; PAM8302AAD drives the doorbell's own **local** speaker (J5, off-board). This is separate from the chime subsystem's amp (below). |
| **Storage** | microSD via SDMMC | Connector J3 (Camera sheet), part no. `5033981892`. Full SD_CLK/CMD/D0–D3/CD bus, all pull-ups present. |
| **Power** | USB-C primary (J2) + optional/unpopulatable battery backup | Battery path: BQ25070DQCT charger (U4) + DW01A protection IC (U3) + MAX17048G fuel gauge (U1). Main 3.3V rail: TPS562201DDCR buck (U2). A second, independent buck (TLV62569DBVR, U6, Main_MCU sheet) generates a `VDD_HP` rail specifically for the ESP32-P4's high-performance core domain — this is **not** the same rail as the main system 3.3V. |
| **Sensors** | AM312 PIR (J4) + weatherproof doorbell pushbutton (SW1) | AM312 confirmed via datasheet to accept 2.7–12V, so the 3.3V supply here is correct (see CHANGELOG — this was flagged and cleared in review). SW1 is a custom part (`PB6B2FM6M2CAL00`, IP65/IP67, 12mm panel-mount, SPST-NO) — this is the actual button a visitor presses, wired to **GPIO40** through a 100Ω series resistor (R18). |
| **Night vision** | Two IR LEDs (D5, D6) + NFET driver (Q3, AO3400A) | **D5 = VSMY1850X01 (850nm)**, **D6 = VSMY2940RG (940nm)** — these are *different* parts/wavelengths, not a matched pair. This may be intentional (mixed covert/semi-visible illumination) or may be a mismatch — **not independently confirmed as intentional; flag for designer confirmation.** |
| **Chime interface** (on-board side only) | ESP32-C3-WROOM-02 (U9) + MAX98357A I2S amp (U10) + J6 (3-pin, off-board) | Drives an external/off-board chime module. See §7 for the M2 fix history (a dead `CHIME_VIN_PROTECTED` rail was removed from this circuit). |

### 2.1 A second on-board button (not the doorbell button)

**SW2** (Main_MCU sheet, generic SMD tactile switch, footprint `SW_SPST_TL3305C`) is wired to **GPIO52**, not GPIO40. This is a small on-board switch, distinct from the weatherproof outdoor doorbell button (SW1, GPIO40). Its exact intended function (factory test button? secondary user function?) was **not determined during this documentation pass** — treat as provisional and confirm with the project owner if its behavior matters for firmware.

---

## 3. Key architecture decisions and why

- **ESP32-S3 → ESP32-P4 + ESP32-C6 migration.** The original design targeted an ESP32-S3. It was replaced with the ESP32-P4 (paired with an ESP32-C6 for WiFi/BT, since the P4 has no native wireless) because **no viable external H.264 hardware encoder existed for the S3** — the P4 has a native hardware video encoder the S3 lacked. *(This rationale is carried over from project history/prior design discussion — not independently re-verified against Espressif datasheets during this documentation pass.)*
- **PCA9555 I/O expander removed entirely.** An earlier revision routed several GPIO-adjacent functions through a PCA9555PW I/O expander (U13) on the Audio_IO sheet. During the full design review (see CHANGELOG), it was found to be unused/superfluous — all of its functions are handled directly by MCU GPIOs — so it, its dedicated pull-up (R24), and its address-strap wiring were **removed entirely**. There is no I/O expander anywhere in the current design.

---

## 4. Sheet map

The project root (`kelly project 3.kicad_sch`) is a **pure hierarchical container** — it has zero directly-placed components, just 6 sheet symbols. (Any component-looking entries you might see cached in its `lib_symbols` block are stale/unused cache leftovers, not real instances.)

| # | Sheet file | Contains |
|---|---|---|
| 1 | **Power.kicad_sch** | USB-C input (J2), battery connector (J1), battery charge/protect/fuel-gauge (U4/U3/U1), main 3.3V buck (U2, TPS562201), power-path diodes/FETs (D1–D3, Q1/Q2), polyfuse (F1), CHG status LED (D4, added this session) |
| 2 | **Main_MCU.kicad_sch** | ESP32-P4NRW32 (U5, 2 schematic units), SPI flash W25Q256JVEIQ (U7), 40MHz crystal (Y1), VDD_HP buck TLV62569 (U6), doorbell button SW1, secondary button SW2, programming test pads TP1–TP5 for the P4 |
| 3 | **Wireless_Coproc.kicad_sch** | ESP32-C6FH4 (U8), 40MHz crystal (Y2), antenna matching network, programming test pads TP6–TP10 for the C6 |
| 4 | **Secondary_MCU_CAN.kicad_sch** | **⚠ ORPHANED — not part of the active design.** Contains an ESP32-WROOM-32E and a SN65HVD230 CAN transceiver, but this sheet is **not instantiated** as a sheet symbol on the root sheet (confirmed by direct inspection — root only has 6 `(sheet ...)` blocks, this file isn't one of them). It exists on disk but has no electrical connection to anything. Unclear whether it's a deprecated earlier revision or a placeholder for a future feature — **do not assume it's live without checking the root sheet yourself.** |
| 5 | **Aux_MCU.kicad_sch** | ESP32-C3-WROOM-02 (U9, drives the chime interface), MAX98357A I2S amp (U10), off-board chime connector (J6, 3-pin), programming test pads TP11–TP15 for the C3 |
| 6 | **Audio_IO.kicad_sch** | ES8388 codec (U11), PAM8302AAD amp (U12), electret mic input (J7, added this session), local speaker output (J5). **No I/O expander** — see §3. |
| 7 | **Camera.kicad_sch** | LI-OV5640-MIPI-AF camera (U15), camera LDO XC6206P282MR (U14), microSD slot (J3), PIR connector (J4), IR LEDs + driver (D5/D6/Q3) |

---

## 5. Known KiCad quirks specific to this project

### 5.1 Apparent Y-axis pin-coordinate inconsistency in certain symbols

Several symbols in this project — **ES8388** (Audio_IO), **BQ25070DQCT** (Power), **ESP32-P4NRW32** (Main_MCU, both schematic units), and **ESP32-C6FH4** (Wireless_Coproc) — appear, when you naively compute `pin_absolute_position = instance_position + local_pin_offset`, to land in the wrong place. The correct position instead requires *subtracting* the local Y offset for these specific parts.

**This was investigated in depth** (see CHANGELOG entry for the sweep/root-cause session). The conclusion: **this is not a data-corruption bug in these specific symbols.** A byte-for-byte comparison of the cached `RF_Module:ESP32-C3-WROOM-02` symbol (which also exhibits this behavior) against KiCad's own officially bundled library found the pin data to be **identical**. The behavior instead appears to be a manifestation of KiCad's own documented internal Y-axis display inconsistencies between UI panels (see GitLab issues [#19886](https://gitlab.com/kicad/code/kicad/-/issues/19886) and [#11988](https://gitlab.com/kicad/code/kicad/-/issues/11988)) — i.e., a KiCad tooling quirk, not a defect specific to this project's parts.

**Practical rule for anyone editing this schematic:** never trust a computed pin position for a multi-pin, non-symmetric part. Before wiring, always verify the real position empirically using one of:
- An existing `no_connect` marker already sitting on that pin (if present).
- Tracing an existing wire from that pin to a known destination.
- Rendering the sheet to SVG (`kicad-cli sch export svg`) and checking where the pin's name label actually appears.

Simple 2-pin symmetric parts (resistors, capacitors, 2-pin connectors) can't be used to detect this, because both candidate coordinates are usually valid endpoints either way — don't use them as a sanity check.

### 5.2 Files can get silently re-saved/reformatted externally

Multiple times this session, schematic files were found modified (via file timestamps and unexpected diffs) between one `kicad-cli` check and the next, without any edit from the assistant session in between — most likely the KiCad GUI auto-saving open files. Observed effects have included wire segments getting merged/restructured in ways that **deleted a needed connection vertex**. **Always re-run ERC (and ideally a netlist export) immediately before trusting "last known clean" status** — don't assume a clean state persists across a work session gap.

### 5.3 Mid-span wire taps require an explicit junction

If you tap a new wire onto the *middle* of an existing wire (rather than at one of its two declared endpoints), **KiCad does not reliably treat this as a connection** unless you also add an explicit `(junction (at X Y) ...)` element at that exact point. Without the junction, the tap can silently fail to connect — this caused two real bugs this session (an R47 pull-up and a flash-chip HOLD pin, both fixed). The safe pattern used throughout this project going forward: split the wire into two segments that share the tap point as a true endpoint, **and** add a junction there.

---

## 6. Programming / test-pad map

All three MCUs (P4, C6, C3) now have UART-based programming/debug access, matching a consistent convention (the P4 itself uses UART for its own external programming access — confirmed no USB connector is wired to its native USB pins, `USB_DM` is intentionally no-connect per spec — so UART was used for the C6 and C3 too, for consistency).

| TP ref | Sheet | MCU | Function |
|---|---|---|---|
| TP1 | Main_MCU | ESP32-P4 (U5) | `BOOT_MODE_PAD` — GPIO0, pull low for download mode |
| TP2 | Main_MCU | ESP32-P4 (U5) | `EN_RESET_PAD` — CHIP_PU/EN |
| TP3 | Main_MCU | ESP32-P4 (U5) | `UART0_TXD_PAD` — GPIO37 |
| TP4 | Main_MCU | ESP32-P4 (U5) | `UART0_RXD_PAD` — GPIO38 |
| TP5 | Main_MCU | ESP32-P4 (U5) | `UART0_GND_PAD` |
| TP6 | Wireless_Coproc | ESP32-C6 (U8) | `BOOT_MODE_PAD` — GPIO0 (pad 6), with new R51 10kΩ pull-up (this pin had none before) |
| TP7 | Wireless_Coproc | ESP32-C6 (U8) | `EN_RESET_PAD` — CHIP_PU (existing R20 10kΩ pull-up, confirmed correct) |
| TP8 | Wireless_Coproc | ESP32-C6 (U8) | `GND_PAD` |
| TP9 | Wireless_Coproc | ESP32-C6 (U8) | `UART0_TXD_PAD` — GPIO16/U0TXD |
| TP10 | Wireless_Coproc | ESP32-C6 (U8) | `UART0_RXD_PAD` — GPIO17/U0RXD |
| TP11 | Aux_MCU | ESP32-C3 (U9) | `BOOT_MODE_PAD` — IO9 (existing R23 10kΩ pull-up, confirmed correct) |
| TP12 | Aux_MCU | ESP32-C3 (U9) | `EN_RESET_PAD` — EN (existing R22 10kΩ pull-up, confirmed correct) |
| TP13 | Aux_MCU | ESP32-C3 (U9) | `UART0_TXD_PAD` — IO21/TXD |
| TP14 | Aux_MCU | ESP32-C3 (U9) | `UART0_RXD_PAD` — IO20/RXD |
| TP15 | Aux_MCU | ESP32-C3 (U9) | `GND_PAD` |

All 15 pads use the same `Connector:TestPoint` footprint style, and every net above was individually confirmed via `kicad-cli sch export netlist` (not just ERC) to contain the expected pad + pull-up + MCU pin.

---

## 7. Current ERC status

**As of 2026-08-30 (final completion pass): 3 errors, 9 warnings.** All 3 errors and all 9 warnings are individually accounted for below — **there is nothing unexplained.**

### 7.1 The 3 errors — all one single known issue

| Error | Location | Explanation |
|---|---|---|
| `pin_not_connected` | Wireless_Coproc, U8 Pin 4 (CHIP_PU) | U8's (ESP32-C6) CHIP_PU/EN pin and its intended pull-up (R20, pre-existing, 10kΩ to +3.3V) and test pad (TP7) do not register as connected via `kicad-cli`, despite extensive verification that the coordinates, wire geometry, and file structure are all correct. See §7.2 for the full investigation record. |
| `pin_not_driven` | Wireless_Coproc, U8 Pin 4 (CHIP_PU) | Same root cause as above — this is the same broken connection reported by a second ERC rule. |
| `pin_not_connected` | Wireless_Coproc, TP7 Pin 1 | Same root cause — TP7 is the test pad on the other end of the same broken connection. |

**This is the one open item in the whole project.** Everything else is clean.

### 7.2 Investigation record for the CHIP_PU issue (exhausted, documented for whoever picks this up)

This was investigated across two full sessions with essentially every technique available short of the interactive GUI:

- **Coordinate correctness**: independently confirmed 3 ways — flip-formula math, SVG-rendered label position, and ERC's own error message all agree the pin is at (115.57mm, 89.535mm).
- **Wire structure**: many different topologies tried (direct wire, split-wire-with-junction, matched local labels on both ends, rerouted paths avoiding a same-row neighboring pin), each byte-verified identical in structure to wires elsewhere in this exact file that `kicad-cli` *does* recognize correctly.
- **File integrity**: paren-balance and nesting checked directly (no corruption), no duplicate references, no duplicate UUIDs (instance-level and pin-level both regenerated fresh as a test — no change), no stacked/duplicate pin declarations at that coordinate (checked directly against a documented KiCad bug pattern, GitLab #22409, that causes similar false negatives — ruled out).
- **Engine round-trip**: `kicad-cli sch upgrade --force` (a genuine load-and-resave through KiCad's real schematic engine, not text editing) was run successfully against the root project file. However, `kicad-cli` **cannot load any of this project's sub-sheet `.kicad_sch` files as a standalone entry point** — confirmed as a general tool limitation (reproduced identically on Camera.kicad_sch and a fully isolated copy of Wireless_Coproc.kicad_sch with its own fresh `.kicad_pro`), not something specific to the CHIP_PU wiring. This means the one tool capable of a genuine non-text-edit fix cannot reach the file that needs it.
- **Environmental factors**: a live KiCad GUI process (`kicad.exe`) was found running against this project mid-session and was suspected as the cause (file-save race condition). It was closed and the project re-checked — **the issue persisted**, ruling out the GUI-conflict theory. (This does NOT mean the GUI conflict theory was wrong about *other* glitches earlier in the project's history — see §5.2 — only that it is not the explanation for *this* specific issue.)

**Bottom line:** the design intent is not in question — R20's pull-up and TP7's placement are correct and match the same pattern used successfully for the equivalent pins on U9 (ESP32-C3) and U5 (ESP32-P4) elsewhere in this same project. This is very likely a narrow `kicad-cli`-specific parsing/connectivity quirk affecting this one pin. **Recommended fix: open `Wireless_Coproc.kicad_sch` in the KiCad GUI, delete the wire segment(s) touching U8 pin 4, and redraw the connection to R20 and TP7 by clicking pin-to-pin.** This is a well under 5-minute manual task and is the only thing standing between this project and a fully clean ERC pass.

### 7.3 The 9 warnings — all explained

| # | Warning | Location | Explanation |
|---|---|---|---|
| 1 | `isolated_pin_label` | Root sheet, label `GPIO50_SPARE` | Intentional, documented spare net — GPIO50 is deliberately left as a labeled-but-unused spare. |
| 2 | `unconnected_wire_endpoint` | (60.325, 85.00) | Cosmetic false positive — this is U9's EN pull-up path; `Net-(U9-EN)` was re-verified via netlist this pass and correctly contains C65, R22, TP12, and U9. |
| 3 | `unconnected_wire_endpoint` | (60.325, 120.65) | Cosmetic false positive — U9's IO9/boot path; `Net-(U9-IO9)` re-verified correct (R23, TP11, U9). |
| 4 | `unconnected_wire_endpoint` | (90.805, 92.71) | Cosmetic false positive — U9's UART RXD path; re-verified correct (TP14, U9). |
| 5 | `unconnected_wire_endpoint` | (90.805, 95.25) | Cosmetic false positive — U9's UART TXD path; re-verified correct (TP13, U9). |
| 6 | `unconnected_wire_endpoint` | (115.57, 62.865) | **This one is real** — it's the R20 side of the open CHIP_PU issue (§7.1/§7.2), not a false positive. |
| 7 | `unconnected_wire_endpoint` | (225.00, 102.235) | Cosmetic false positive — U8's GPIO0/boot path; re-verified correct (R51, TP6, U8). |
| 8 | `unconnected_wire_endpoint` | (171.45, 104.775) | Cosmetic false positive — U8's UART TXD path; re-verified correct (TP9, U8). |
| 9 | `unconnected_wire_endpoint` | (171.45, 107.315) | Cosmetic false positive — U8's UART RXD path; re-verified correct (TP10, U8). |

The "cosmetic false positive" pattern (rows 2–5, 7–9) is `kicad-cli` ERC's endpoint-checker disagreeing with its own netlist/ratsnest engine — the netlist is authoritative and was re-checked fresh for every single one of these during this completion pass, not carried over from memory.

### 7.4 What's fully verified vs. still provisional

**Fully verified this pass** (fresh ERC + fresh netlist re-check, not from memory): Power, Main_MCU, Aux_MCU, Audio_IO, Camera — all clean. Wireless_Coproc — clean except the one documented CHIP_PU issue.

**Also verified this pass:**
- Every component across all 6 active sheets has a non-empty footprint assigned — checked directly, zero missing.
- No duplicate reference designators anywhere in the project (one apparent duplicate, U5, is the same physical ESP32-P4 correctly split across 2 schematic units — verified legitimate, not a bug).
- No accidental duplicate component placements (same part + same position under a different reference) anywhere — checked directly, zero found.
- All 194 nets in the current netlist have unique names — no silent net-splits anywhere in the project (the CAM_2V8/CAM_DVDD_1V5-style bug does not recur elsewhere).
- The shared I2C0 bus correctly bridges all 4 intended devices (U1, U11, U15, U5) across 4 different sheets — spot-checked directly via netlist.
- USB-C connector (J2): both D+/D- pairs (A6/A7 and B6/B7) and both SBU pins are intentionally unconnected — this connector is used for power delivery only (VBUS + CC), consistent with the original design review's already-approved "USB-C CC pull-downs" and "USB_DP/DM floating-per-spec" notes. Not a new finding, just re-confirmed during this pass's unconnected-pin sweep.
- All 82 currently-unconnected pins project-wide were categorized: the 3 belonging to the open CHIP_PU issue, plus 79 that are legitimate spare/unused MCU GPIOs, literal datasheet NC pins, or unused codec/amp channels not used by this design.

**Provisional / flagged for follow-up, not fixed or fully characterized (unchanged from the documentation pass):**
- D5/D6 IR LED wavelength mismatch (850nm vs 940nm) — §2, may be intentional.
- SW2's exact functional purpose — §2.1.
- Secondary_MCU_CAN.kicad_sch's status (deprecated vs. future placeholder) — §4.
- Power-path diode/FET topology (D1/D2/D3 + Q1/Q2 exact mux logic) has still not been exhaustively re-traced — the high-level description in §2 is based on partial netlist tracing, not a full topology confirmation.

---

## 8. Final completion pass summary

**Session:** Final completion pass, 2026-08-30.

**Schematic status: NOT YET 100% complete.** One manual step remains — see §7.1/§7.2. Every other verification in this pass (footprints, programming infrastructure, duplicate check, net-name consistency, unconnected-pin audit) came back clean. Once the single CHIP_PU wire is redrawn in the GUI per the §7.2 recommendation and ERC confirmed at 0 errors, this project is ready to hand off to PCB layout — no other blocking items are known.

| Metric | Value |
|---|---|
| Total real components (excl. power symbols/flags) | 180 |
| Total nets | 194 (112 named/real nets, 82 single-pin unconnected placeholders) |
| ERC errors | 3 (all one known issue, §7.1) |
| ERC warnings | 9 (8 explained false-positives + 1 documented spare, §7.3) |
| Sheets in active hierarchy | 7 (Power, Main_MCU, Wireless_Coproc, Aux_MCU, Audio_IO, Camera, + root container) |
| Orphaned/inactive sheets | 1 (Secondary_MCU_CAN.kicad_sch — not instantiated) |
| MCUs with complete programming infrastructure | 3 of 3 (P4 fully clean; C6 and C3 clean except the one CHIP_PU wire on C6) |
