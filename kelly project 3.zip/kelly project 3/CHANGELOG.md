# Kelly Project 3 — Changelog

High-level history of major work sessions on this schematic, in order. This is not a line-by-line commit log — it's meant to let someone quickly tell what's already been checked vs. what's still open. See `PROJECT_STATUS.md` for the current-state snapshot.

---

## 1. Initial architecture (pre-dates detailed session history available here)

Original design targeted an **ESP32-S3** as the main MCU.

## 2. ESP32-P4 migration

Main MCU changed from ESP32-S3 to **ESP32-P4NRW32 + ESP32-C6FH4 co-processor** (SDIO-connected), because no viable external H.264 hardware encoder existed for the S3 — the P4 has a native one. This is the architecture the project has used since.

## 3. Missing-component additions

A pass to add components/subsystems that were missing from the schematic:
- Duplicate camera symbol conflict resolved.
- Custom symbol + footprint created for the doorbell pushbutton (`PB6B2FM6M2CAL00`), built from the real part's mechanical spec — no manufacturer/SnapEDA symbol existed.
- Custom footprint created for the camera module (`LI-OV5640-MIPI-AF`) from its official datasheet.
- Missing footprints assigned (SW3-era button, D2-era diode — since superseded, see §5).
- Iteratively wired every unconnected pin/component across all sheets based on datasheet application circuits, driving ERC to 0 errors / 0 warnings.
- Added previously-missing subsystems: SD card slot, PIR sensor, weatherproof doorbell button, IR LEDs + driver, local audio amp, battery-backup circuitry (charger/protection/fuel-gauge).

## 4. Full independent design review

A structured review (blocking / major / minor severity tiers) was run against the schematic and cross-checked against real manufacturer datasheets (not assumptions) for every specific claim before acting on it. Two significant review claims turned out to be **incorrect** and were rejected rather than blindly implemented:
- **TPS562201 feedback divider "wrong voltage" claim** — rejected. The reviewer's math assumed a 0.6V feedback reference; the TPS562201's real reference (confirmed via TI datasheet SLVSD91 and independently via its DigiKey listing) is **0.768V**. With R3=33kΩ/R4=10kΩ, Vout = 0.768 × (1 + 33/10) = **3.30V — correct as originally designed.** See the inline note on the Power sheet (§ below) so this doesn't get "corrected" incorrectly in the future.
- A second reviewer claim (PCB9555-related pin conflict) was also found to be based on incorrect assumptions and not acted on.

Confirmed-real issues from the same review were fixed, including (non-exhaustive): SD_MODE pull-up on the chime amp, GPIO0/CAM_PWDN/CAM_RESET/FLASH_WP/FLASH_HOLD pull-ups, an SDIO bus missing pull-ups, a D2 TVS diode with the wrong voltage class for its rail, a GPIO50/GPIO52 accidental net short (caused by a wire passing exactly through an unrelated point — a genuine silent-short pattern, distinct from the mid-span-tap-doesn't-connect pattern found later), a microphone circuit added to the audio codec, and UART0 factory-programming test pads added for the main MCU (TP1–TP5).

Two items were **removed** during this pass after confirming they were dead/unused, not fixed in place:
- The **PCA9555PW I/O expander** (Audio_IO sheet) — confirmed via netlist that none of its functions were actually load-bearing; removed entirely along with its dedicated pull-up and address-strap wiring.
- The **`CHIME_VIN_PROTECTED`** rail on the Aux_MCU sheet (a fused/TVS-clamped copy of the off-board chime connector's raw VIN pin) — confirmed via netlist that nothing consumed it (the chime subsystem's MCU and amp both already draw from the main 3.3V rail). The fuse, TVS diode, and the dead wiring were removed; the connector pin was left properly unconnected (no-connect flagged) rather than dangling.
- A charge-status LED was added on the battery charger's CHG pin (Power sheet) at the project owner's request, correct polarity confirmed via netlist (current flows +3.3V → limit resistor → anode → cathode → CHG when the charger sinks current).

## 5. B1/B4/B6 re-confirmation pass

The project owner asked for three specific "blocking" items from the design review to be independently re-confirmed, since they weren't explicitly called out as fixed or as no-change-needed in the prior summary:
- **B1 (TPS562201 divider):** re-confirmed no change needed — see §4 above for the math.
- **B4 (D2 TVS diode):** core fix (part swapped to `SMAJ5.0A`) was confirmed correct, but stale BOM metadata left over from the original (wrong) part — manufacturer, package, purchase-URL fields still referencing the old `SM8S36A` — was found and cleaned up.
- **B6 (GPIO50/GPIO52 short):** re-confirmed via fresh netlist export — `GPIO50_SPARE` net contains only U5 pin93, GPIO52 is on its own separate net with the doorbell circuit. Fix holds.

## 6. C6 / C3 programming infrastructure

The ESP32-C6FH4 (U8) and ESP32-C3-WROOM-02 (U9) co-processors had no programming/boot access at all. Before adding it, their EN/boot-strap pull-ups were checked — contrary to the initial assumption that U9's EN pull-up was missing, it (and U9's IO9 pull-up, R23) turned out to **already exist and be correctly wired** (R22/R23, both confirmed 10kΩ to +3.3V via netlist); no duplicate was added. U8's existing CHIP_PU pull-up (R20) was also confirmed correct.

What was actually missing and got added:
- A GPIO0 pull-up for U8 (R51, 10kΩ) — this one genuinely had none.
- Ten new test pads (TP6–TP15) giving both MCUs the same BOOT/EN/GND/UART0-TX/UART0-RX access pattern already used for the main MCU (TP1–TP5), using the same `Connector:TestPoint` footprint convention. Full map in `PROJECT_STATUS.md` §6.

While verifying the fix for U8's antenna matching network was independently checked to still be intact (U6/U14/U15 routing double-check requested by the project owner at the same time) — confirmed all three route correctly, not just placed.

## 7. Full-project mid-span-tap sweep + Y-axis root-cause investigation

Two systemic follow-up investigations, prompted by the R47/flash-HOLD bugs found in §4/§6:

1. **Geometric sweep of all 7 sheets** for any other wire-endpoint-lands-mid-span-on-another-wire situations (the same class of bug as R47). Found and individually netlist-verified 4 more candidates; all turned out to already have proper junction markers (or, in one case, to simply not have caused a short) — **no further silent breaks found.**
2. **Root-cause investigation into the recurring "Y-axis flip" pattern** seen across several custom-imported symbols. Conclusion: **not a data bug** — a byte-for-byte comparison of one affected symbol against KiCad's own official library found identical pin data. The behavior is most likely a manifestation of KiCad's own documented internal Y-axis display inconsistencies (GitLab #19886, #11988), not something specific to how these symbols were created. See `PROJECT_STATUS.md` §5.1 for the practical guidance this produced (always verify pin positions empirically).

## 8. Documentation pass (this session)

Added `PROJECT_STATUS.md`, this changelog, and a purpose-summary text note on every sheet (plus an orphan-status note on Secondary_MCU_CAN and an update to the existing DVDD1.5V note on the Camera sheet).

While fact-checking the documentation against the live files, a regression was caught on `Wireless_Coproc.kicad_sch`: a wire segment connecting U8's antenna matching network to its ANT pin had gone missing, most likely a side effect of a since-rerouted wire from the C6/C3 programming-pad work (§6) overlapping it on the same line. Attempted to fix it (reroute + restore), but the fix kept being undone between one check and the next despite verified-correct edits on disk. Root cause traced to **a live `kicad.exe` GUI process with this project open** — the file was being raced between direct edits and the GUI's own autosave. This likely explains several vaguer "external file modification" glitches noted earlier in the session too (§4, §6) — probably the same live-GUI conflict the whole time, not a KiCad-internal file-processing quirk as originally assumed.

**As a result, this session ends with `Wireless_Coproc.kicad_sch` NOT confirmed ERC-clean** — see `PROJECT_STATUS.md` §7.2 for the exact state and what's needed (close the KiCad GUI, then re-run ERC fresh) before trusting or continuing to edit that sheet. Every other sheet remains at its last-confirmed-clean state from earlier in the session.

Also corrected a documentation-only error caught during fact-checking: an earlier session summary had described GPIO52/SW2 as "the real doorbell button circuit." Direct verification found this backwards — the actual weatherproof doorbell button (SW1, custom `PB6B2FM6M2CAL00` part) is wired to **GPIO40**, not GPIO52. SW2 is a separate, small on-board tactile switch of undetermined purpose. No schematic change was needed (the GPIO50/52 short fix from §4 was still correct — it just wasn't "the doorbell circuit" specifically) — this was purely a documentation correction, now reflected accurately in `PROJECT_STATUS.md`.

## 9. Final completion pass (2026-08-30)

Ruled out the live-GUI-conflict theory from §8 as the explanation for the CHIP_PU issue specifically: closed the KiCad GUI process and re-checked — the issue persisted unchanged. Tried one further approach per the project owner's request: `kicad-cli sch upgrade --force`, a genuine load-and-resave through KiCad's real schematic engine rather than text editing. This succeeded on the root project file but revealed a separate, more fundamental limitation — `kicad-cli` cannot load *any* of this project's sub-sheet `.kicad_sch` files as a standalone entry point (confirmed on multiple healthy sheets and in a fully isolated test copy with its own project file), so the tool has no way to reach and re-save the one file that needs it. Concluded this is a narrow, unresolved `kicad-cli` quirk specific to this one pin, fully documented in `PROJECT_STATUS.md` §7.2, with a GUI-based fix recommended (expected under 5 minutes).

Ran a full verification sweep per the project owner's request: footprint completeness (0 missing across all sheets), duplicate-reference check (0 real duplicates — the one apparent hit, U5, is a legitimate 2-unit symbol), duplicate-placement check (0 found), net-name uniqueness (194/194 unique, no silent splits), and a full categorization of all 82 currently-unconnected pins project-wide (3 belong to the known CHIP_PU issue, the rest are legitimate spares/NC-per-datasheet/unused channels — including reconfirming the USB-C connector's data lines are intentionally unconnected, matching the original design review).

Final ERC: 3 errors / 9 warnings, every single one individually explained in `PROJECT_STATUS.md` §7.1/§7.3 — nothing unaccounted for. Project is **not yet** marked 100% complete, pending the one manual GUI step.
